This Python module implements the binary protocol used by the collectd Network 
plugin to let you send arbitrary numeric data to collectd servers. Other than 
turning on the Network plugin on the destination collectd server, no 
configuration is needed.
